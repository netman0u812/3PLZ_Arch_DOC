Reserved for future systemd units (portal/bastion separation, sync jobs).
