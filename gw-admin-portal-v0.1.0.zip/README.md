# gw-admin-portal (v0.1.0) — Admin Management Plane Add-on for GW-Builder (Rocky Linux 9)

This package deploys an **admin-only** web access portal that provides:
- **PAM + OTP (TOTP)** authentication for admin users (e.g., `admin-mm`)
- A **browser-based shell** (recommended: Apache Guacamole) that drops admins into a **bastion shell**
- From bastion, admins use **SSH key-based auth** to access **GW nodes** over a dedicated **management VLAN**
- Centralized admin home directories and SSH keys shared to GW nodes via **NFSv3** on a dedicated **L2-only VLAN**

> This admin portal is **separate from the tenant/user data plane**. Tenant users never access this portal.

## Topology assumptions
- Portal host has **2 NICs**:
  - NIC1 = **Mgmt-Access (L3)**: inbound HTTPS :443 for admin browsers
  - NIC2 = **Mgmt trunk** carrying:
    - VLAN 90 = **mgmt-services** (SSH to GW nodes)
    - VLAN 91 = **nfs-l2** (L2-only NFS share)
- GW nodes have:
  - Outside NIC (no trunk) for underlay + IPsec
  - Inside NIC (trunk) carrying VLAN 90 + VLAN 91 (plus any inside VLANs)

## Quick start
1. Copy config:
```bash
sudo install -d /etc/gw-admin-portal
sudo cp conf/admin-portal.conf.example /etc/gw-admin-portal/admin-portal.conf
sudo vi /etc/gw-admin-portal/admin-portal.conf
```

2. Install:
```bash
sudo /opt/gw-admin-portal/bin/adminctl.sh install
```

3. Configure networking (creates VLAN subinterfaces with nmcli):
```bash
sudo /opt/gw-admin-portal/bin/adminctl.sh configure-network
```

4. Configure OTP:
```bash
sudo /opt/gw-admin-portal/bin/adminctl.sh configure-otp
```

5. Configure NFS export:
```bash
sudo /opt/gw-admin-portal/bin/adminctl.sh configure-nfs
```

6. Configure Guacamole (repo-dependent; guided):
```bash
sudo /opt/gw-admin-portal/bin/adminctl.sh configure-guac
```

7. Apply firewall policy:
```bash
sudo /opt/gw-admin-portal/bin/adminctl.sh apply-firewall
```

8. Validate:
```bash
sudo /opt/gw-admin-portal/bin/adminctl.sh health
```

## Files
- `bin/adminctl.sh` — main control script (install/configure/firewall/health)
- `conf/admin-portal.conf.example` — configuration template
- `templates/nftables/gw-admin-portal.nft` — nftables ruleset template
- `templates/nfs/*` — NFSv3 fixed-port hardening templates
- `docs/ARCHITECTURE.txt` — architecture and security model
- `docs/BUILD-GUIDE.txt` — step-by-step build guide
- `docs/TEST-PLAN.txt` — functional testing plan

Version: v0.1.0
Generated: 20260218-151223
